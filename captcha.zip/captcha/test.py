import pytesseract
from PIL import Image
import cv2 as cv
import ddddocr
import time

# image = cv.imread('1.jpg')
# blur = cv.pyrMeanShiftFiltering(image, sp=8, sr=60)

# gray = cv.cvtColor(blur, cv.COLOR_BGR2GRAY)
# ret, binary = cv.threshold(gray, 0, 255, cv.THRESH_BINARY_INV | cv.THRESH_OTSU)

# kernel = cv.getStructuringElement(cv.MORPH_RECT, (3, 2))
# bin1 = cv.morphologyEx(binary, cv.MORPH_OPEN, kernel)

# kernel = cv.getStructuringElement(cv.MORPH_OPEN, (2, 3))
# bin2 = cv.morphologyEx(bin1, cv.MORPH_OPEN, kernel)

# cv.bitwise_not(bin2, bin2)

# test_message = Image.fromarray(bin2)
# text = pytesseract.image_to_string(test_message)

# print(text)

ocr = ddddocr.DdddOcr(show_ad=False)

image = open('3.jpg', 'rb')
image_bytes = image.read()
image.close()
start = time.time()
res = ocr.classification(image_bytes)
print(res)
end = time.time()
print(end - start)